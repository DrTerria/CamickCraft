ItemEvents.modification(event => {
    // dragon chestplate buff
    const dragoncolors = ["red", "bronze", "green", "gray", "blue", "white", "sapphire", "silver", "electric", "amythest", "copper", "black"]
    for (const i of dragoncolors) {
        event.modify("iceandfire:armor_" + i + "_chestplate", item => {
            item.armorProtection = 8;
            item.armorToughness = 3;
        })
    }
})