ServerEvents.recipes(event => { 
    event.shapeless(
        Item.of('simplyswords:emberblade'),
        [
            'minecraft:netherite_sword',
            'iceandfire:fire_dragon_blood'
        ]
    )
    event.shaped(
        Item.of('simplyswords:bramblethorn'),
        [
            'ABC',
            'BDB',
            'EBA'
        ],
        {
            E: 'minecraft:slime_ball',
            B: 'minecraft:stick',
            C: 'alexsmobs:poison_bottle',
            A: 'minecraft:string',
            D: 'minecraft:wooden_sword'
        }
    )
    event.shapeless(
        Item.of('simplyswords:toxic_longsword'),
        [
            'irons_spellbooks:nature_rune',
            'minecraft:poisonous_potato',
            'minecraft:stone_sword',
            'irons_spellbooks:nature_rune'
        ]
    )
    event.shaped(
        Item.of('simplyswords:emberlash'),
        [
            ' AB',
            'ACA',
            'AA '
        ],
        {
            A: 'minecraft:iron_nugget',
            C: 'minecraft:iron_ingot',
            B: 'ars_nouveau:fire_essence'
        }
    )
    event.shaped(
        Item.of('simplyswords:hiveheart'),
        [
            'ABA',
            'CDC',
            ' E '
        ],
        {
            D: 'minecraft:beehive',
            C: 'minecraft:honeycomb',
            E: 'minecraft:stick',
            B: 'minecraft:honeycomb_block',
            A: 'minecraft:honey_block'
        }
    )
    event.shaped(
        Item.of('simplyswords:tempest'),
        [
            ' AF',
            'BCD',
            'GE '
        ],
        {
            C: 'simplyswords:iron_chakram',
            E: 'irons_spellbooks:nature_rune',
            A: 'irons_spellbooks:lightning_rune',
            B: 'irons_spellbooks:arcane_rune',
            D: 'irons_spellbooks:fire_rune',
            F: 'ars_nouveau:fire_essence',
            G: 'ars_nouveau:air_essence'
        }
    )
    event.shaped(
        Item.of('simplyswords:storms_edge'),
        [
            ' AB',
            'ACA',
            'BA '
        ],
        {
            B: 'irons_spellbooks:lightning_bottle',
            C: 'simplyswords:iron_twinblade',
            A: 'minecraft:iron_ingot'
        }
    )
    event.shaped(
        Item.of('simplyswords:frostfall'),
        [
            'ABA',
            'BCB',
            ' A '
        ],
        {
            A: 'minecraft:blue_ice',
            B: 'minecraft:snow_block',
            C: 'minecraft:snowball'
        }
    )
    event.shaped(
        Item.of('simplyswords:mjolnir'),
        [
            'AAA',
            'BCB',
            'DED'
        ],
        {
            E: 'minecraft:iron_nugget',
            C: 'irons_spellbooks:lightning_bottle',
            B: 'minecraft:iron_ingot',
            D: 'irons_spellbooks:lightning_rune',
            A: 'minecraft:iron_block'
        }
    )
    event.shaped(
        Item.of('simplyswords:livyatan'),
        [
            'ABC',
            'DEB',
            'EDA'
        ],
        {
            D: 'irons_spellbooks:permafrost_shard',
            A: 'quark:permafrost',
            C: 'mowziesmobs:ice_crystal',
            B: 'minecraft:polished_blackstone',
            E: 'irons_spellbooks:frosted_helve'
        }
    )
    event.shaped(
        Item.of('simplyswords:ribboncleaver'),
        [
            'ABA',
            'BCB',
            'DBA'
        ],
        {
            B: 'create:iron_sheet',
            D: 'simplyswords:iron_claymore',
            A: 'minecraft:red_wool',
            C: 'quark:red_corundum_cluster'
        }
    )
    event.shaped(
        Item.of('simplyswords:arcanethyst'),
        [
            ' AB',
            'CDA',
            'EC '
        ],
        {
            A: 'irons_spellbooks:arcane_ingot',
            D: 'simplyswords:iron_halberd',
            C: 'irons_spellbooks:arcane_essence',
            E: 'minecraft:amethyst_shard',
            B: 'irons_spellbooks:arcane_rune'
        }
    )
    event.shaped(
        Item.of('simplyswords:flamewind'),
        [
            'ABC',
            'BDB',
            'ABA'
        ],
        {
            A: 'alexscaves:heavy_bone',
            B: 'alexscaves:tough_hide',
            C: 'alexscaves:tectonic_shard',
            D: 'alexscaves:primal_magma'
        }
    )
})