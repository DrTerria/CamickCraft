ServerEvents.recipes(event => {
    // attempt at changing the dragonsteel recipe
    event.remove({output: 'iceandfire:dragonsteel_fire_ingot'})
    event.remove({output: 'iceandfire:dragonsteel_ice_ingot'})
    event.remove({output: 'iceandfire:dragonsteel_lightning_ingot'})

    event.custom({
        type: "iceandfire:dragonforge",
        dragon_type: "fire",
        cook_time: 1000,
        input: {item: "advancednetherite:netherite_diamond_ingot"},
        blood: {item: "iceandfire:fire_dragon_blood"},
        result: {item: "iceandfire:dragonsteel_fire_ingot"}
    })
    event.custom({
        type: "iceandfire:dragonforge",
        dragon_type: "ice",
        cook_time: 1000,
        input: {item: "advancednetherite:netherite_diamond_ingot"},
        blood: {item: "iceandfire:ice_dragon_blood"},
        result: {item: "iceandfire:dragonsteel_ice_ingot"}
    })
    event.custom({
        type: "iceandfire:dragonforge",
        dragon_type: "lightning",
        cook_time: 1000,
        input: {item: "advancednetherite:netherite_diamond_ingot"},
        blood: {item: "iceandfire:lightning_dragon_blood"},
        result: {item: "iceandfire:dragonsteel_lightning_ingot"}
    })
    // change poison essence recipe
    event.remove({output: "alexsmobs:poison_bottle"})
    event.shapeless(
        Item.of('alexsmobs:poison_bottle'),
        [
            'alexsmobs:rattlesnake_rattle'
        ]
    )
    event.shapeless(
        Item.of('alexsmobs:poison_bottle'),
        [
            'iceandfire:myrmex_stinger'
        ]
    )
    event.shapeless(
        Item.of('bosses_of_mass_destruction:brimstone_nectar'),
        [
            'cataclysm:ignitium_ingot',
            'minecraft:honeycomb',
            'apotheosis:infused_breath'
        ]
    )
    event.shaped(
        Item.of('simplyswords:brimstone_claymore'),
        [
            'FAB',
            'CDA',
            'ECF'
        ],
        {
            B: 'bosses_of_mass_destruction:obsidian_heart',
            E: 'integrated_simply_swords:iceandfire/dragonsteel_fire/claymore',
            A: 'bosses_of_mass_destruction:brimstone_nectar',
            D: 'ars_elemental:fire_focus',
            C: 'alexscaves:tectonic_shard',
            F: 'protection_pixel:flarerod'
        }
    )

})