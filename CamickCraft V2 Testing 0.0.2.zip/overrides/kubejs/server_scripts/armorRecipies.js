ServerEvents.recipes(event => {
    // divine armor recipe
    event.remove({output: 'immersive_armors:divine_helmet'})
    event.remove({output: 'immersive_armors:divine_chestplate'})
    event.remove({output: 'immersive_armors:divine_leggings'})
    event.remove({output: 'immersive_armors:divine_boots'})
    
    event.shaped(
        Item.of('immersive_armors:divine_helmet'),
        [
            'ABA',
            'ACA',
            '   '
        ],
        {
            A: 'minecraft:gold_ingot',
            B: 'minecraft:emerald',
            C: 'minecraft:iron_helmet'
        }
    )
    event.shaped(
        Item.of('immersive_armors:divine_chestplate'),
        [
            'ABA',
            'ACA',
            'ADA'
        ],
        {
            C: 'minecraft:totem_of_undying',
            A: 'minecraft:gold_ingot',
            B: 'irons_spellbooks:holy_rune',
            D: 'minecraft:iron_chestplate'
        }
    )
    event.shaped(
        Item.of('immersive_armors:divine_leggings'),
        [
            'ABA',
            'ACA',
            'A A'
        ],
        {
            A: 'minecraft:gold_ingot',
            C: 'minecraft:iron_leggings',
            B: 'irons_spellbooks:holy_rune'
        }
    )
    event.shaped(
        Item.of('immersive_armors:divine_boots'),
        [
            '   ',
            'ABA',
            'C C'
        ],
        {
            C: 'minecraft:gold_ingot',
            A: 'irons_spellbooks:holy_rune',
            B: 'minecraft:iron_boots'
        }
    )
    // cursium smithing recipes
    event.remove({output: 'cataclysm:cursium_helmet'})
    event.remove({output: 'cataclysm:cursium_chestplate'})
    event.remove({output: 'cataclysm:cursium_leggings'})
    event.remove({output: 'cataclysm:cursium_boots'})

    event.smithing(
        'cataclysm:cursium_helmet',
        'cataclysm:cursium_upgrade_smithing_template',
        'cataclysm:bone_reptile_helmet',
        'cataclysm:cursium_ingot'
    )
    event.smithing(
        'cataclysm:cursium_chestplate',
        'cataclysm:cursium_upgrade_smithing_template',
        'cataclysm:bone_reptile_chestplate',
        'cataclysm:cursium_ingot'
    )
    event.smithing(
        'cataclysm:cursium_leggings',
        'cataclysm:cursium_upgrade_smithing_template',
        'immersive_armors:wither_leggings',
        'cataclysm:cursium_ingot'
    )
    event.smithing(
        'cataclysm:cursium_boots',
        'cataclysm:cursium_upgrade_smithing_template',
        'immersive_armors:wither_boots',
        'cataclysm:cursium_ingot'
    )
    // bone reptile recipe changes
    event.remove({output: 'cataclysm:bone_reptile_helmet'})
    event.remove({output: 'cataclysm:bone_reptile_chestplate'})
    event.shaped(
    Item.of('cataclysm:bone_reptile_chestplate'),
        [
            'A A',
            'BCB',
            'DBD'
        ],
        {
            C: 'alexscaves:heavy_bone',
            D: 'cataclysm:koboleton_bone',
            A: 'alexscaves:tectonic_shard',
            B: 'cataclysm:ancient_metal_ingot'
        }
    )
    event.shaped(
    Item.of('cataclysm:bone_reptile_helmet'),
        [
            'ABA',
            'CDC',
            '   '
        ],
        {
            A: 'cataclysm:koboleton_bone',
            D: 'cataclysm:kobolediator_skull',
            B: 'alexscaves:tectonic_shard',
            C: 'cataclysm:ancient_metal_ingot'
        }
    )
    // Ignitium smithing changes
    event.remove({output: 'cataclysm:ignitium_helmet'})
    event.remove({output: 'cataclysm:ignitium_chestplate'})
    event.remove({output: 'cataclysm:ignitium_leggings'})
    event.remove({output: 'cataclysm:ignitium_boots'})

    event.smithing(
        'cataclysm:ignitium_helmet',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_fire_helmet',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_helmet',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_ice_helmet',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_helmet',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_lightning_helmet',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_chestplate',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_fire_chestplate',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_chestplate',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_ice_chestplate',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_chestplate',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_lightning_chestplate',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_leggings',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_fire_leggings',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_leggings',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_ice_leggings',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_leggings',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_lightning_leggings',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_boots',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_fire_boots',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_boots',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_ice_boots',
        'cataclysm:ignitium_ingot'
    )
    event.smithing(
        'cataclysm:ignitium_boots',
        'cataclysm:ignitium_upgrade_smithing_template',
        'iceandfire:dragonsteel_lightning_boots',
        'cataclysm:ignitium_ingot'
    )
})